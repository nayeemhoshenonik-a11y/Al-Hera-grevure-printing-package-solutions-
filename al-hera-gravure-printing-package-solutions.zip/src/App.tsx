/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Printer, 
  Package, 
  ShieldCheck, 
  Clock, 
  Palette, 
  Globe, 
  Phone, 
  Mail, 
  MapPin, 
  Facebook,
  ChevronRight,
  Layers,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { motion } from 'motion/react';

const services = [
  {
    title: "সব ধরণের প্রিন্টিং প্যাকেজ",
    description: "আটা, ময়দা, সুজি, ডিটারজেন্ট, চা, মশলা, চিপস, চানাচুর, বিস্কুট এবং আইসক্রিমের প্যাকেট ইত্যাদি।",
    icon: Package,
  },
  {
    title: "উন্নত প্রযুক্তি",
    description: "ডিজিটাল ও ম্যানুয়াল সিলিন্ডার প্রিন্টিং এবং ব্লকপ্রিন্ট প্রযুক্তি ব্যবহার করে নিখুঁত ছাপ।",
    icon: Printer,
  },
  {
    title: "বিশেষায়িত প্যাকেজিং",
    description: "সার ও বীজের প্যাকেট, টাইলস পুটিং, দুধের প্যাক এবং গার্মেন্টস এক্সেসরিজ প্যাকেজিং।",
    icon: Layers,
  },
  {
    title: "অনলাইন উদ্যোক্তাদের জন্য",
    description: "অনলাইনের পলিপ্রিন্ট করার সুব্যবস্থা ও কাস্টমাইজড সমাধান।",
    icon: Globe,
  },
  {
    title: "নিজস্ব ডিজাইন স্টুডিও",
    description: "অভিজ্ঞ ডিজাইনার দিয়ে আপনার ব্র্যান্ডের জন্য আকর্ষণীয় ও প্রিমিয়াম ডিজাইন।",
    icon: Palette,
  },
  {
    title: "মাল্টি-লেয়ার ল্যামিনেশন",
    description: "PET, LDPE, Foil ল্যামিনেশন যা পণ্যের সতেজতা রাখে দীর্ঘকাল।",
    icon: Zap,
  }
];

const features = [
  {
    title: "প্রিমিয়াম লুক",
    description: "আপনার পণ্যের আকর্ষণ বাড়াতে আমরা দিচ্ছি আধুনিক ফিনিশিং।",
    icon: ShieldCheck,
  },
  {
    title: "টেকসই সিলিং",
    description: "নিখুঁত ফিনিশিং এবং টেকসই সিলিং নিশ্চিত করে পণ্যের নিরাপত্তা।",
    icon: CheckCircle2,
  },
  {
    title: "সঠিক সময়ে ডেলিভারি",
    description: "আপনার ব্যবসার গতি বজায় রাখতে আমরা সময়ের প্রতি দায়বদ্ধ।",
    icon: Clock,
  }
];

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <div className="bg-emerald-600 p-1.5 rounded-lg">
                <Printer className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight text-slate-900 hidden sm:block">
                Al-Hera <span className="text-emerald-600">Printing</span>
              </span>
            </div>
            <div className="flex items-center gap-4">
              <a href="tel:01950648154" className="flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-emerald-600 transition-colors">
                <Phone className="w-4 h-4" />
                <span className="hidden md:block">01950-648154</span>
              </a>
              <a href="#contact" className="bg-emerald-600 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-emerald-700 transition-all shadow-md shadow-emerald-200">
                যোগাযোগ করুন
              </a>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 lg:py-32 overflow-hidden bg-slate-900">
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <img 
              src="https://picsum.photos/seed/printing/1920/1080?blur=5" 
              alt="Background" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="max-w-3xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h1 className="text-4xl md:text-6xl font-extrabold text-white leading-tight mb-6">
                  Al-Hera Gravure Printing <br />
                  <span className="text-emerald-400">Package Solutions</span>
                </h1>
                <p className="text-xl text-slate-300 mb-8 leading-relaxed">
                  আমরা শুধু প্যাকেট বানাই না, আমরা আপনার পণ্যের সুরক্ষা এবং প্রিমিয়াম লুক নিশ্চিত করি। আধুনিক গ্র্যাভিউর প্রিন্টিং এবং মাল্টি-লেয়ার ল্যামিনেশন প্রযুক্তির নিশ্চয়তা।
                </p>
                <div className="flex flex-wrap gap-4">
                  <a href="#services" className="bg-emerald-500 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-emerald-600 transition-all flex items-center gap-2 group">
                    আমাদের সেবাসমূহ
                    <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </a>
                  <a href="#contact" className="bg-white/10 backdrop-blur-sm text-white border border-white/20 px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all">
                    ফ্রি কনসালটেশন
                  </a>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Stats/Quick Info */}
        <section className="py-12 bg-white border-b border-slate-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {features.map((feature, idx) => (
                <div key={idx} className="flex items-start gap-4 p-6 rounded-2xl hover:bg-slate-50 transition-colors">
                  <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
                    <feature.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900 mb-1">{feature.title}</h3>
                    <p className="text-slate-600 text-sm">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section id="services" className="py-24 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">আমাদের সেবাসমূহ</h2>
              <p className="text-slate-600 max-w-2xl mx-auto">
                আমরা আধুনিক প্রযুক্তি ব্যবহার করে আপনার ব্র্যান্ডের জন্য সেরা প্যাকেজিং সমাধান প্রদান করি।
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, idx) => (
                <motion.div 
                  key={idx}
                  whileHover={{ y: -5 }}
                  className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:shadow-emerald-900/5 transition-all"
                >
                  <div className="bg-emerald-50 w-14 h-14 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                    <service.icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
                  <p className="text-slate-600 leading-relaxed">
                    {service.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA / Quality Section */}
        <section className="py-24 bg-emerald-600 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/3 h-full opacity-10 pointer-events-none">
            <Printer className="w-full h-full text-white rotate-12" />
          </div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-8">
              আপনার ব্র্যান্ডের জন্য সেরা প্যাকেজিং খুঁজছেন?
            </h2>
            <p className="text-emerald-100 text-xl mb-10 max-w-3xl mx-auto">
              আমাদের অভিজ্ঞ ডিজাইনার এবং উন্নত প্রযুক্তি আপনার পণ্যের সতেজতা এবং প্রিমিয়াম লুক নিশ্চিত করবে।
            </p>
            <a href="tel:01950648154" className="inline-flex items-center gap-3 bg-white text-emerald-600 px-10 py-5 rounded-2xl font-bold text-xl hover:bg-emerald-50 transition-all shadow-2xl">
              <Phone className="w-6 h-6" />
              কল করুন: 01950-648154
            </a>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              <div>
                <h2 className="text-3xl font-bold text-slate-900 mb-8">যোগাযোগের ঠিকানা</h2>
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="bg-slate-100 p-3 rounded-xl text-slate-600">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">অফিস</h4>
                      <p className="text-slate-600">
                        রিসোের্সফুল পল্টন সিটি (জি. ফ্লোর)<br />
                        পুরানা পল্টন, ঢাকা-১০০০।
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-slate-100 p-3 rounded-xl text-slate-600">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">ফোন</h4>
                      <p className="text-slate-600">01950-648154</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-slate-100 p-3 rounded-xl text-slate-600">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">ই-মেইল</h4>
                      <p className="text-slate-600">alheraenterprise202@gmail.com</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="bg-slate-100 p-3 rounded-xl text-slate-600">
                      <Facebook className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 mb-1">ফেসবুক</h4>
                      <a 
                        href="https://www.facebook.com/share/1AWjnFhgLC/" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-emerald-600 hover:underline"
                      >
                        Al-Hera Printing Facebook Page
                      </a>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-slate-50 p-8 md:p-12 rounded-3xl border border-slate-200">
                <h3 className="text-2xl font-bold text-slate-900 mb-6">আমাদের মেসেজ দিন</h3>
                <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">আপনার নাম</label>
                      <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="নাম লিখুন" />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-2">ফোন নম্বর</label>
                      <input type="tel" className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="01XXX-XXXXXX" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">বিষয়</label>
                    <input type="text" className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="কি ধরণের প্যাকেজ প্রয়োজন?" />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-2">মেসেজ</label>
                    <textarea rows={4} className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all" placeholder="আপনার বিস্তারিত লিখুন..."></textarea>
                  </div>
                  <button className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200">
                    মেসেজ পাঠান
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <Printer className="w-6 h-6 text-emerald-500" />
              <span className="text-xl font-bold text-white">Al-Hera Printing</span>
            </div>
            <div className="text-sm">
              © {new Date().getFullYear()} Al-Hera Gravure Printing Package Solutions. All rights reserved.
            </div>
            <div className="flex gap-6">
              <a href="https://www.facebook.com/share/1AWjnFhgLC/" className="hover:text-white transition-colors">
                <Facebook className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
